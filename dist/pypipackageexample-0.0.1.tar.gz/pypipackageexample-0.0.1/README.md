# pypipackageexample
 
Este es un README de ejemplo para que mis alumnos aprendan