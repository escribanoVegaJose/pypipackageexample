from setuptools import setup, find_packages

setup(
    name= 'pypipackageexample', 
    version= '0.0.1',
    license= 'MIT',
    description= "paquete de prueba para una clase de Udemy",
    author= "Jose Escribano Vega",
    packages=find_packages(),
    url= 'https://github.com/escribanoVegaJose/pypipackageexample'
)