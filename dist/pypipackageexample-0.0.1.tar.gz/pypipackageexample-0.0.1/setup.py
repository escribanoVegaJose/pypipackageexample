from setuptools import setup

setup(
    name= 'pypipackageexample', 
    version= '0.0.1',
    license= 'MIT',
    description= "paquete de prueba para una clase de Udemy",
    author= "Jose Escribano Vega",
    autthor_email= "escribanovegajose@gmail.com", 
    url= 'https://github.com/escribanoVegaJose/pypipackageexample'
)